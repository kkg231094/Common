package com.capgemini.ars.dto;

public class Users {

	private String userName;
	private String password;
	private String role;
	private long mobileNum;
	
	public Users() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param userName
	 * @param password
	 * @param role
	 * @param mobileNum
	 */
	public Users(String userName, String password, String role, long mobileNum) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
		this.mobileNum = mobileNum;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @return the mobileNum
	 */
	public long getMobileNum() {
		return mobileNum;
	}

	/**
	 * @param mobileNum the mobileNum to set
	 */
	public void setMobileNum(long mobileNum) {
		this.mobileNum = mobileNum;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password
				+ ", role=" + role + ", mobileNum=" + mobileNum + "]";
	}
	
}
