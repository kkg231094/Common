package com.capgemini.ars.dao;

import com.capgemini.ars.dto.Users;



public interface UsersDao {

	boolean validateUser(Users user);
}
