package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;




import java.sql.ResultSet;

import org.jboss.security.auth.spi.Users.User;

import com.capgemini.ars.dto.Users;
import com.capgemini.ars.factory.DBUtil;

public class UsersDaoImpl implements UsersDao{

	@Override
	public boolean validateUser(Users user) {
		String sqlValid = "SELECT * FROM users WHERE username=? AND password=?";
		try(Connection conn = DBUtil.getConnection()) {
			
			PreparedStatement pstm = conn.prepareStatement(sqlValid);
			
			pstm.setString(1, user.getUserName());
			pstm.setString(2, user.getPassword());
			
			ResultSet res = pstm.executeQuery();
			while(res.next()){
				
				user.setRole(res.getString("role"));
				
				
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

}
