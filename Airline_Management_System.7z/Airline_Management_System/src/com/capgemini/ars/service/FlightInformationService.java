package com.capgemini.ars.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.ars.dto.FlightInformation;

public interface FlightInformationService {
	public void addFlight(FlightInformation flightInfo);
	public List<String> fetchFlightNumber();
	public FlightInformation fetchFlightDetails(String flightNo);
	public void  updateFlightDetails(FlightInformation flightInfo, String oldFlightNumber);
	public List<String> getDestination();
	public List<FlightInformation> viewFlightDetails(String flightDate, String destinationValue);
	public List<FlightInformation> searchFlight(FlightInformation flightInfo);

}
