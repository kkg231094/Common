package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmpDao;
import com.cg.entities.Employee;

@Service
@Transactional
public class EmpServiceImpl implements EmpService 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Autowired
	EmpDao empDao;
	
	@Override
	public long addEmployee(Employee emp) {
		return empDao.addEmployee(emp);
	}

	@Override
	public List<Employee> viewAll() {
		// TODO Auto-generated method stub
		return empDao.viewAll();
	}

	@Override
	public Employee searchById(Employee employee) {
		// TODO Auto-generated method stub
		return empDao.searchById(employee);
	}

	@Override
	public long updateEmp(Employee emp) {
		// TODO Auto-generated method stub
		return empDao.updateEmp(emp);
	}

	@Override
	public void deleteEmp(Employee employee) {
		empDao.deleteEmp(employee);
		
	}

}
