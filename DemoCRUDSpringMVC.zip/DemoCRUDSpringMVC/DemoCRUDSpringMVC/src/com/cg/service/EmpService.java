package com.cg.service;

import java.io.Serializable;
import java.util.List;

import com.cg.entities.Employee;

public interface EmpService extends Serializable 
{
	public long addEmployee(Employee emp);
	public List<Employee> viewAll();
	public Employee searchById(Employee employee);
	public long updateEmp(Employee emp);
	public void deleteEmp(Employee employee);
}
