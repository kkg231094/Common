package com.cg.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entities.Employee;
import com.cg.service.EmpService;

@Controller
public class EmpController 
{
	@Autowired
	EmpService empService;
	
	@RequestMapping("/index")
	public String getHomePage(Model model) 
	{
		model.addAttribute("empList", empService.viewAll());
		model.addAttribute("employee", new Employee());
		return "index";
	}
	
	@RequestMapping(value="/save")
	public String addEmp(@ModelAttribute("employee") @Valid Employee employee,BindingResult result, Model model)
	{
		System.out.println("hellllooooo");
		if(result.hasErrors())
		{
			System.out.println("hellllooooo");
			return "index";
		}
		else
		{
		empService.addEmployee(employee);
		model.addAttribute("message", "Employee with Id "+employee.getEmpId()+"has been inserted");
		return "redirect:/index.html";
		}
	}
	
	@RequestMapping(value="/updateEmployee")
	public String reUpdateEmp(Model model)
	{
		model.addAttribute("employee", new Employee());
		return "updateEmployee";
	}
	
	@RequestMapping(value="/updateEmp")
	public String updateEmployee(Employee employee, Model model)
	{
		employee = empService.searchById(employee);
		model.addAttribute("employee", employee);
		return "updateRecords";
		
	}
	
	@RequestMapping(value="/updatedEmployee")
	public String updatedEmployee(@ModelAttribute("employee") @Valid Employee employee, BindingResult result, Model model)
	{
		if(result.hasErrors())
		{
			return "updateRecords";
		}
		else
		{
		empService.updateEmp(employee);
		model.addAttribute("message", "Employee with Id "+employee.getEmpId()+"has been updated");
		return "redirect:/index.html";
		}
	}
	
	@RequestMapping(value="/redirection")
	public String redirect()
	{
		return "Menu";
	}
	
	@RequestMapping(value="/deleteEmpo")
	public String deleteEmployee(@ModelAttribute("employee") Employee employee, Model model)
	{
		employee = empService.searchById(employee);
		System.out.println(employee);
		empService.deleteEmp(employee);
		return "redirect:/index.html";
	}
	
	@RequestMapping(value="/deleteEmp")
	public String redirection(Model model)
	{
		model.addAttribute("employee", new Employee());
		return "deleteEmployee";
	}
	
	/*empService.updateEmp(employee);
	model.addAttribute("message", "Employee with Id "+employee.getEmpId()+"has been updated");*/
}
