package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entities.Employee;

@Repository
public class EmpDaoImpl implements EmpDao 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@PersistenceContext
	private EntityManager entitymanager;

	@Override
	public long addEmployee(Employee emp) 
	{
		System.out.println(emp);
		entitymanager.persist(emp);
		entitymanager.flush();
		System.out.println(emp);
		return emp.getEmpId();
	}

	@Override
	public List<Employee> viewAll() 
	{
		TypedQuery<Employee> query = entitymanager.createQuery("SELECT e FROM Employee e", Employee.class);
		return query.getResultList();
	}

	@Override
	public Employee searchById(Employee employee) {
		return entitymanager.find(Employee.class, employee.getEmpId());
		/*TypedQuery<Employee> query = entitymanager.createQuery("SELECT e FROM Employee e WHERE e.empId="+empId, Employee.class);
		return query.getSingleResult();*/
	}

	@Override
	public long updateEmp(Employee emp) 
	{
		entitymanager.merge(emp);
		return emp.getEmpId();
	}

	@Override
	public void deleteEmp(Employee employee) 
	{
		entitymanager.remove(employee);
	}

}
