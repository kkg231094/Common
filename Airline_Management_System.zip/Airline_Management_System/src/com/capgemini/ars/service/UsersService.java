package com.capgemini.ars.service;

import com.capgemini.ars.dto.Users;

public interface UsersService {
	boolean validateUser(Users user);
	

}
