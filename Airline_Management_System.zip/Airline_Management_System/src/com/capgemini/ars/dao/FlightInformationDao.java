package com.capgemini.ars.dao;

import java.util.HashMap;
import java.util.List;

import com.capgemini.ars.dto.FlightInformation;

public interface FlightInformationDao {
	public void addFlight(FlightInformation flightInfo);
	public List<String> fetchFlightNumber();
	public FlightInformation fetchFlightDetails(String flightNo);
	public void updateFlightInformation(FlightInformation flightInfo, String oldFlightNumber);
	public List<String> getDestination();
	public List<FlightInformation> viewFlightDetails(String flightDate, String destinationValue);

}
