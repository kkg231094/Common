package com.cg.appl.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.dtos.Student;
import com.cg.appl.services.StudentServices;

// http://localhost:8081/SpringMVC10StudentProject/admitNewStudent.html
//http://localhost:8081/SpringMVC10StudentProject/listStudents.html
//http://localhost:8081/SpringMVC10StudentProject/studentDetails.html?id=xxx
@Controller
//@RequestMapping(name="/students")
public class StudentWebController 
{
	@Resource(name="studentServices")
	private StudentServices services;
	
	//Insert Function
	//Action1 - getEntryForm, Action2-postEntryForm

	
	//Action1-get an entry form
		/*@RequestMapping("/admitNewStudent")
		public String getEntryForm(Model model)
		{
			Student student = new Student();
			model.addAttribute("student", student);
			return "entryForm";
		}*/
		
		//Action2 post Student Data
		/*@RequestMapping(name="/admitNewStudent", method=RequestMethod.POST)
		public String postStudentData(@ModelAttribute Student student, Model model)
		{
			boolean isInserted = services.insertNewStudent(student);
			return isInserted?"Success":"entryForm";
			
		}*/
	
	
	//get a single record on Student ID
	//Action3- getFormForId, Action4- See student Details
	
	//View all students
	//Action5-seeAllStudents
		@RequestMapping("/listStudents")
		public String seeAllRecords(Model model)
		{
			List<Student> list = services.getAllStudents();
			
			model.addAttribute("listStudents", list);
			return "listStudents";
		}
		
		@RequestMapping(value="/studentDetails")
		public String getStudentDetails(@RequestParam("id") int stdId, Model model)
		{
			System.out.println(stdId);
			
			Student student = services.getStudent(stdId);
			System.out.println(student);
			
			model.addAttribute("student", student);
			return "updateStdForm";
		}
		
		@RequestMapping(name="/updateStudent", method=RequestMethod.POST)
		public String postStudentData(@ModelAttribute @Valid Student student, BindingResult result, Model model)
		{
			if(result.hasErrors())
			{
				return "updateStdForm";
			}
			else
			{
				boolean isUpdated = services.updateStudent(student);
				System.out.println("Is Student Update? "+isUpdated);
				return isUpdated?"successUpdate":"updateStdForm";
			}
			
		}
}























