create table students(
			studentId number(4) PRIMARY KEY,
			firstName varchar2(10),
			lastName varchar2(10),
			dtJoin Date);